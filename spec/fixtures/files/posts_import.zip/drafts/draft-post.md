---
title: "Draft From Subdirectory"
status: draft
---

This is a draft post from a subdirectory.
