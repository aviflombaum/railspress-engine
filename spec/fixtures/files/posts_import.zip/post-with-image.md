---
title: "Post With Header Image"
status: published
header_image: images/header.png
---

Post with a header image attached.
