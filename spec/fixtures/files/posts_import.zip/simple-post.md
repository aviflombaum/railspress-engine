---
title: "Simple Post"
status: published
---

A simple published post.
